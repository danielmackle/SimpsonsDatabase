﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjectManagment.objects
{
    class Employee
    {
        private int employeeNo;
        private string employeeName;
        private int departmentNo;

        public Employee(int employeeNo, string employeeName, int departmentNo)
        {
            this.EmployeeNo = employeeNo;
            this.EmployeeName = employeeName;
            this.DepartmentNo = departmentNo;
        }

        public Employee()
        {

        }

        public int EmployeeNo { get => employeeNo; set => employeeNo = value; }
        public string EmployeeName { get => employeeName; set => employeeName = value; }
        public int DepartmentNo { get => departmentNo; set => departmentNo = value; }
    }
}
