﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjectManagment.objects
{
    class Department
    {
        private int departmentNo;
        private string departmentName;

        public Department()
        {

        }

        public Department(int departmentNo, string departmentName)
        {
            this.DepartmentNo = departmentNo;
            this.DepartmentName = departmentName;
        }

        public int DepartmentNo { get => departmentNo; set => departmentNo = value; }
        public string DepartmentName { get => departmentName; set => departmentName = value; }
    }
}
