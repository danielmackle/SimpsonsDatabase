﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;

namespace ProjectManagment.objects
{
    class Project
    {
        private decimal projectBudget;
        private int projectCode;
        private string projectManager;
        private string projectTitle;
        private DateTime projectStartDate;
        private DateTime projectEndDate;
        private bool projectCompleted;

        public decimal ProjectBudget { get => projectBudget; set => projectBudget = value; }
        public int ProjectCode { get => projectCode; set => projectCode = value; }
        public string ProjectManager 
        { 
            get => projectManager;
            set { if (CheckPresent(value))
                    projectManager = value;
                else
                    throw new Exception("Manager Name cannot be left blank"); 
            }
        }
        public string ProjectTitle { get => projectTitle; set => projectTitle = value; }
        public DateTime ProjectStartDate 
        { 
            get => projectStartDate;
            set
            {
                if (CheckProjectDay(value))
                    projectStartDate = value;
                else
                    throw new Exception("Projects must start between Monday and Friday");
            }
        }
        public DateTime ProjectEndDate 
        { 
            get => projectEndDate; 
            set               
            {
                if (CheckEndDate(value))
                    projectEndDate = value;
                else
                    throw new Exception("Projects must end between Monday and Friday and be at least 7 days long");
            }
        }
        public bool ProjectCompleted { get => projectCompleted; set => projectCompleted = value; }

        public Project()
        {

        }

        public Project(decimal projectBudget, int projectCode, string projectManager, string projectTitle, DateTime projectStartDate, DateTime projectEndDate, bool projectCompleted)
        {
            this.projectBudget = projectBudget;
            this.projectCode = projectCode;
            this.projectManager = projectManager;
            this.projectTitle = projectTitle;
            this.projectStartDate = projectStartDate;
            this.projectEndDate = projectEndDate;
            this.projectCompleted = projectCompleted;
        }

        private bool CheckPresent(string value)
        {
            if (String.IsNullOrWhiteSpace(value)) return false;
            else return true;
        }

        private bool CheckProjectDay(DateTime value)
        {
            if((int)value.DayOfWeek == 6 || (int) value.DayOfWeek == 0)
                return false;
            else
                return true;
        }

        private bool CheckEndDate(DateTime value)
        {
            if(CheckProjectDay(value) & value >= ProjectStartDate.AddDays(7))
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
