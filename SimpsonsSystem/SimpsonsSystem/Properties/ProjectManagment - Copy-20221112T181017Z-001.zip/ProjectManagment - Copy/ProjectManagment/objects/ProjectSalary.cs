﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjectManagment.objects
{
    class ProjectSalary
    {
        private int projectCode;
        private int employeeNo;
        private decimal hourlyRate;

        public ProjectSalary()
        {

        }

        public ProjectSalary(int projectCode, int employeeNo, decimal hourlyRate)
        {
            this.ProjectCode = projectCode;
            this.EmployeeNo = employeeNo;
            this.HourlyRate = hourlyRate;
        }

        public int ProjectCode { get => projectCode; set => projectCode = value; }
        public int EmployeeNo { get => employeeNo; set => employeeNo = value; }
        public decimal HourlyRate { get => hourlyRate; set => hourlyRate = value; }
    }
}
