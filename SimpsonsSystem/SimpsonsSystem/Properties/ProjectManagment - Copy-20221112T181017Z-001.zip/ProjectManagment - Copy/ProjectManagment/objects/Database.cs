﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace ProjectManagment.objects
{
    class Database
    {
        private SqlCommand cmd;
        private SqlConnection conn;
        private SqlDataReader rdr;

        public Database(SqlCommand cmd, SqlConnection conn, SqlDataReader rdr)
        {
            this.Cmd = cmd;
            this.Conn = conn;
            this.Rdr = rdr;
        }

        public Database()
        {

        }

        public SqlCommand Cmd { get => cmd; set => cmd = value; }
        public SqlConnection Conn { get => conn; set => conn = value; }
        public SqlDataReader Rdr { get => rdr; set => rdr = value; }

        public bool Connect()
        {
            SqlConnectionStringBuilder scStrBuild = new SqlConnectionStringBuilder();
            scStrBuild.DataSource = "(LocalDB)\\mssqllocaldb";
            scStrBuild.AttachDBFilename = "|DataDirectory|ProjectManagement.mdf";
            scStrBuild.IntegratedSecurity = true;
            conn = new SqlConnection(scStrBuild.ToString());
            cmd = new SqlCommand();
            try
            {
                conn.Open();
                return true;
            }

            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
                return false;
            }
        }
    }
}
