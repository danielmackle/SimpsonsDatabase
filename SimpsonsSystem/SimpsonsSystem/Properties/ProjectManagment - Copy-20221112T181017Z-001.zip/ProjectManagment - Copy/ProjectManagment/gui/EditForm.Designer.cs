﻿
namespace ProjectManagment.gui
{
    partial class EditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSelectProject = new System.Windows.Forms.Label();
            this.lblProjectID = new System.Windows.Forms.Label();
            this.lblProjectTitle = new System.Windows.Forms.Label();
            this.lblProjectManager = new System.Windows.Forms.Label();
            this.lblProjectBudget = new System.Windows.Forms.Label();
            this.lblStartdate = new System.Windows.Forms.Label();
            this.lblEndDate = new System.Windows.Forms.Label();
            this.cboboxSelect = new System.Windows.Forms.ComboBox();
            this.tbxProjectID = new System.Windows.Forms.TextBox();
            this.tbxProjectTitle = new System.Windows.Forms.TextBox();
            this.tbxProjectManager = new System.Windows.Forms.TextBox();
            this.tbxProjectBudget = new System.Windows.Forms.TextBox();
            this.monCalStart = new System.Windows.Forms.MonthCalendar();
            this.monthCalEnd = new System.Windows.Forms.MonthCalendar();
            this.cbxCompleted = new System.Windows.Forms.CheckBox();
            this.btnConfirmEdit = new System.Windows.Forms.Button();
            this.btnCancelEdit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblSelectProject
            // 
            this.lblSelectProject.ForeColor = System.Drawing.Color.Lime;
            this.lblSelectProject.Location = new System.Drawing.Point(21, 26);
            this.lblSelectProject.Name = "lblSelectProject";
            this.lblSelectProject.Size = new System.Drawing.Size(300, 43);
            this.lblSelectProject.TabIndex = 0;
            this.lblSelectProject.Text = "Select Project to edit:";
            // 
            // lblProjectID
            // 
            this.lblProjectID.ForeColor = System.Drawing.Color.Lime;
            this.lblProjectID.Location = new System.Drawing.Point(21, 75);
            this.lblProjectID.Name = "lblProjectID";
            this.lblProjectID.Size = new System.Drawing.Size(191, 43);
            this.lblProjectID.TabIndex = 1;
            this.lblProjectID.Text = "Project ID";
            // 
            // lblProjectTitle
            // 
            this.lblProjectTitle.ForeColor = System.Drawing.Color.Lime;
            this.lblProjectTitle.Location = new System.Drawing.Point(21, 142);
            this.lblProjectTitle.Name = "lblProjectTitle";
            this.lblProjectTitle.Size = new System.Drawing.Size(191, 43);
            this.lblProjectTitle.TabIndex = 2;
            this.lblProjectTitle.Text = "Project Title";
            // 
            // lblProjectManager
            // 
            this.lblProjectManager.ForeColor = System.Drawing.Color.Lime;
            this.lblProjectManager.Location = new System.Drawing.Point(21, 215);
            this.lblProjectManager.Name = "lblProjectManager";
            this.lblProjectManager.Size = new System.Drawing.Size(247, 43);
            this.lblProjectManager.TabIndex = 3;
            this.lblProjectManager.Text = "Project Manager";
            // 
            // lblProjectBudget
            // 
            this.lblProjectBudget.ForeColor = System.Drawing.Color.Lime;
            this.lblProjectBudget.Location = new System.Drawing.Point(12, 282);
            this.lblProjectBudget.Name = "lblProjectBudget";
            this.lblProjectBudget.Size = new System.Drawing.Size(228, 43);
            this.lblProjectBudget.TabIndex = 4;
            this.lblProjectBudget.Text = "Project Budget";
            // 
            // lblStartdate
            // 
            this.lblStartdate.ForeColor = System.Drawing.Color.Lime;
            this.lblStartdate.Location = new System.Drawing.Point(918, 261);
            this.lblStartdate.Name = "lblStartdate";
            this.lblStartdate.Size = new System.Drawing.Size(268, 43);
            this.lblStartdate.TabIndex = 5;
            this.lblStartdate.Text = "Project Start Date";
            // 
            // lblEndDate
            // 
            this.lblEndDate.ForeColor = System.Drawing.Color.Lime;
            this.lblEndDate.Location = new System.Drawing.Point(901, 339);
            this.lblEndDate.Name = "lblEndDate";
            this.lblEndDate.Size = new System.Drawing.Size(247, 43);
            this.lblEndDate.TabIndex = 6;
            this.lblEndDate.Text = "Project End Date";
            // 
            // cboboxSelect
            // 
            this.cboboxSelect.BackColor = System.Drawing.Color.Gray;
            this.cboboxSelect.ForeColor = System.Drawing.Color.Lime;
            this.cboboxSelect.FormattingEnabled = true;
            this.cboboxSelect.Location = new System.Drawing.Point(327, 23);
            this.cboboxSelect.Name = "cboboxSelect";
            this.cboboxSelect.Size = new System.Drawing.Size(776, 33);
            this.cboboxSelect.TabIndex = 7;
            this.cboboxSelect.SelectedIndexChanged += new System.EventHandler(this.projectPicked);
            // 
            // tbxProjectID
            // 
            this.tbxProjectID.BackColor = System.Drawing.Color.Gray;
            this.tbxProjectID.ForeColor = System.Drawing.Color.Lime;
            this.tbxProjectID.Location = new System.Drawing.Point(210, 72);
            this.tbxProjectID.Name = "tbxProjectID";
            this.tbxProjectID.Size = new System.Drawing.Size(277, 32);
            this.tbxProjectID.TabIndex = 8;
            // 
            // tbxProjectTitle
            // 
            this.tbxProjectTitle.BackColor = System.Drawing.Color.Gray;
            this.tbxProjectTitle.ForeColor = System.Drawing.Color.Lime;
            this.tbxProjectTitle.Location = new System.Drawing.Point(210, 153);
            this.tbxProjectTitle.Name = "tbxProjectTitle";
            this.tbxProjectTitle.Size = new System.Drawing.Size(277, 32);
            this.tbxProjectTitle.TabIndex = 9;
            // 
            // tbxProjectManager
            // 
            this.tbxProjectManager.BackColor = System.Drawing.Color.Gray;
            this.tbxProjectManager.ForeColor = System.Drawing.Color.Lime;
            this.tbxProjectManager.Location = new System.Drawing.Point(210, 215);
            this.tbxProjectManager.Name = "tbxProjectManager";
            this.tbxProjectManager.Size = new System.Drawing.Size(277, 32);
            this.tbxProjectManager.TabIndex = 10;
            // 
            // tbxProjectBudget
            // 
            this.tbxProjectBudget.BackColor = System.Drawing.Color.Gray;
            this.tbxProjectBudget.ForeColor = System.Drawing.Color.Lime;
            this.tbxProjectBudget.Location = new System.Drawing.Point(200, 293);
            this.tbxProjectBudget.Name = "tbxProjectBudget";
            this.tbxProjectBudget.Size = new System.Drawing.Size(277, 32);
            this.tbxProjectBudget.TabIndex = 11;
            // 
            // monCalStart
            // 
            this.monCalStart.Location = new System.Drawing.Point(662, 149);
            this.monCalStart.Name = "monCalStart";
            this.monCalStart.TabIndex = 12;
            // 
            // monthCalEnd
            // 
            this.monthCalEnd.Location = new System.Drawing.Point(662, 329);
            this.monthCalEnd.Name = "monthCalEnd";
            this.monthCalEnd.TabIndex = 13;
            // 
            // cbxCompleted
            // 
            this.cbxCompleted.AutoSize = true;
            this.cbxCompleted.ForeColor = System.Drawing.Color.Lime;
            this.cbxCompleted.Location = new System.Drawing.Point(12, 353);
            this.cbxCompleted.Name = "cbxCompleted";
            this.cbxCompleted.Size = new System.Drawing.Size(209, 29);
            this.cbxCompleted.TabIndex = 14;
            this.cbxCompleted.Text = "Project Completed ?";
            this.cbxCompleted.UseVisualStyleBackColor = true;
            // 
            // btnConfirmEdit
            // 
            this.btnConfirmEdit.BackColor = System.Drawing.Color.Gray;
            this.btnConfirmEdit.ForeColor = System.Drawing.Color.Lime;
            this.btnConfirmEdit.Location = new System.Drawing.Point(901, 77);
            this.btnConfirmEdit.Name = "btnConfirmEdit";
            this.btnConfirmEdit.Size = new System.Drawing.Size(224, 52);
            this.btnConfirmEdit.TabIndex = 15;
            this.btnConfirmEdit.Text = "Confirm Edit";
            this.btnConfirmEdit.UseVisualStyleBackColor = false;
            this.btnConfirmEdit.Click += new System.EventHandler(this.editClick);
            // 
            // btnCancelEdit
            // 
            this.btnCancelEdit.BackColor = System.Drawing.Color.Gray;
            this.btnCancelEdit.ForeColor = System.Drawing.Color.Lime;
            this.btnCancelEdit.Location = new System.Drawing.Point(665, 77);
            this.btnCancelEdit.Name = "btnCancelEdit";
            this.btnCancelEdit.Size = new System.Drawing.Size(224, 52);
            this.btnCancelEdit.TabIndex = 16;
            this.btnCancelEdit.Text = "Cancel Edit";
            this.btnCancelEdit.UseVisualStyleBackColor = false;
            // 
            // EditForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.HotPink;
            this.ClientSize = new System.Drawing.Size(1127, 533);
            this.Controls.Add(this.btnCancelEdit);
            this.Controls.Add(this.btnConfirmEdit);
            this.Controls.Add(this.cbxCompleted);
            this.Controls.Add(this.monthCalEnd);
            this.Controls.Add(this.monCalStart);
            this.Controls.Add(this.tbxProjectBudget);
            this.Controls.Add(this.tbxProjectManager);
            this.Controls.Add(this.tbxProjectTitle);
            this.Controls.Add(this.tbxProjectID);
            this.Controls.Add(this.cboboxSelect);
            this.Controls.Add(this.lblEndDate);
            this.Controls.Add(this.lblStartdate);
            this.Controls.Add(this.lblProjectBudget);
            this.Controls.Add(this.lblProjectManager);
            this.Controls.Add(this.lblProjectTitle);
            this.Controls.Add(this.lblProjectID);
            this.Controls.Add(this.lblSelectProject);
            this.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "EditForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "EditForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSelectProject;
        private System.Windows.Forms.Label lblProjectID;
        private System.Windows.Forms.Label lblProjectTitle;
        private System.Windows.Forms.Label lblProjectManager;
        private System.Windows.Forms.Label lblProjectBudget;
        private System.Windows.Forms.Label lblStartdate;
        private System.Windows.Forms.Label lblEndDate;
        private System.Windows.Forms.ComboBox cboboxSelect;
        private System.Windows.Forms.TextBox tbxProjectID;
        private System.Windows.Forms.TextBox tbxProjectTitle;
        private System.Windows.Forms.TextBox tbxProjectManager;
        private System.Windows.Forms.TextBox tbxProjectBudget;
        private System.Windows.Forms.MonthCalendar monCalStart;
        private System.Windows.Forms.MonthCalendar monthCalEnd;
        private System.Windows.Forms.CheckBox cbxCompleted;
        private System.Windows.Forms.Button btnConfirmEdit;
        private System.Windows.Forms.Button btnCancelEdit;
    }
}