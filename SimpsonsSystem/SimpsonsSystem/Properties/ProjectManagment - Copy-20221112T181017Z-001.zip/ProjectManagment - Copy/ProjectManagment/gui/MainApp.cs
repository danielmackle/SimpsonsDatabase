﻿using ProjectManagment.objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ProjectManagment.gui
{
    public partial class MainApp : Form
    {
        private static Database db;

        internal static Database Db { get => db; set => db = value; }

        public MainApp()
        {
            InitializeComponent();
            db = new Database();
            if (!db.Connect())
            {
                MessageBox.Show("Database Connection Unsuccessful.", "Error");
            }
        }

        private void btnSearchClick(object sender, EventArgs e)
        {
            SearchForm sf = new SearchForm();
            sf.Show();
        }

        private void btnEditClick(object sender, EventArgs e)
        {
            EditForm edit = new EditForm();
            edit.Show();
        }

        private void addClick(object sender, EventArgs e)
        {
            AddProject add = new AddProject();
            add.Show();
        }
    }
}
