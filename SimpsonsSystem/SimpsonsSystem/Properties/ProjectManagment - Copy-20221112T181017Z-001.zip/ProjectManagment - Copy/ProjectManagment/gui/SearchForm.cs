﻿using ProjectManagment.dbAccess;
using ProjectManagment.gui;
using ProjectManagment.objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectManagment
{
    public partial class SearchForm : Form
    {
        Database db;
        public SearchForm()
        {
            InitializeComponent();
            db = new Database();
            if (db.Connect())
            {
                MessageBox.Show("Database Connect Successful.", "Success");
                initComboBox(); 
            }
            else
            {
                MessageBox.Show("Database Connection Unsuccessful.", "Error");
            }

            
        }

        public void initComboBox()
        {
            string[] queryItems = { "Select all projects that have a budget over 15,000", "Select all projects that M Phillips manages","Select this and Enter Project Name" };
            for (int i = 0; i < queryItems.Length; i++)
            {
                queryCBox.Items.Add(queryItems[i]);
            }
        }

        private void btnSearchClick(object sender, EventArgs e)
        {
            ProjectDBAccess projectDBAccess = new ProjectDBAccess(db);
            DataTable dt = new DataTable();

            if (queryCBox.SelectedIndex == -1)
            {
                MessageBox.Show("You have not selected a query");
            }
            else
            {
                switch (queryCBox.SelectedIndex)
                {
                    case 0:
                        {
                            projectDBAccess.GetAllProjectsWithBudget(15000, 4);
                            dt = projectDBAccess.GetProjectDataTable();
                            resultsDataGrid.DataSource = dt;
                            break;
                        }
                    case 1:
                        {
                            projectDBAccess.GetAllProjectsWithManager("M Phillips");
                            dt = projectDBAccess.GetProjectDataTable();
                            resultsDataGrid.DataSource = dt;
                            break;
                        }
                    case 2:
                        {
                            ProjectSearchForm goodForm = new ProjectSearchForm();
                            goodForm.Show();
                            this.Hide();
                            break;

                        }
                    default:
                        lblResultsSetSize.Text = "0";
                        break;
                }
            }
        }

        private void SearchTextClick(object sender, EventArgs e)
        {
            ProjectDBAccess projectDBAccess = new ProjectDBAccess(db);

            if (tbxProjectId.Text == null)
            {
                MessageBox.Show("Please enter a ProjectID");
            }
            else
            {
                try
                {
                    projectDBAccess.GetProjectWithID(Convert.ToInt32(tbxProjectId.Text));
                    Project Gary = projectDBAccess.GetProjectObject();
                    lblprojectResults.Text = "Project ID: " + Gary.ProjectCode +
                    "\n" + "Project Title: " + Gary.ProjectTitle +
                    "\n" + "Project Manager: " + Gary.ProjectManager +
                    "\n" + "Project Budget: " + Gary.ProjectBudget;
                }
                catch
                {
                    MessageBox.Show("Invalid ProjectID, Please try again");
                }
            }
        }
    }
}
