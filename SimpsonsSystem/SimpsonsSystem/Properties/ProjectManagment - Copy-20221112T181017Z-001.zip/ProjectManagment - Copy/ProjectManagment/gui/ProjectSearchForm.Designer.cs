﻿
namespace ProjectManagment.gui
{
    partial class ProjectSearchForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbxName = new System.Windows.Forms.TextBox();
            this.dgvMain = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.btnSearch = new System.Windows.Forms.Button();
            this.employeeDGV = new System.Windows.Forms.DataGridView();
            this.lblEmployeeTbl = new System.Windows.Forms.Label();
            this.lblNoOfEmployee = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvMain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeDGV)).BeginInit();
            this.SuspendLayout();
            // 
            // tbxName
            // 
            this.tbxName.BackColor = System.Drawing.Color.DarkRed;
            this.tbxName.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tbxName.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.tbxName.Location = new System.Drawing.Point(351, 38);
            this.tbxName.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tbxName.Name = "tbxName";
            this.tbxName.Size = new System.Drawing.Size(561, 32);
            this.tbxName.TabIndex = 0;
            // 
            // dgvMain
            // 
            this.dgvMain.AllowUserToAddRows = false;
            this.dgvMain.BackgroundColor = System.Drawing.Color.DarkRed;
            this.dgvMain.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvMain.Cursor = System.Windows.Forms.Cursors.Cross;
            this.dgvMain.GridColor = System.Drawing.SystemColors.ActiveCaption;
            this.dgvMain.Location = new System.Drawing.Point(86, 75);
            this.dgvMain.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dgvMain.Name = "dgvMain";
            this.dgvMain.RowHeadersWidth = 62;
            this.dgvMain.RowTemplate.Height = 33;
            this.dgvMain.Size = new System.Drawing.Size(904, 173);
            this.dgvMain.TabIndex = 1;
            this.dgvMain.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DGVcellClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(406, 8);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(321, 25);
            this.label1.TabIndex = 2;
            this.label1.Text = "Enter name of the project you seek";
            // 
            // btnSearch
            // 
            this.btnSearch.BackColor = System.Drawing.Color.Maroon;
            this.btnSearch.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSearch.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.btnSearch.Location = new System.Drawing.Point(783, 5);
            this.btnSearch.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnSearch.Name = "btnSearch";
            this.btnSearch.Size = new System.Drawing.Size(127, 29);
            this.btnSearch.TabIndex = 3;
            this.btnSearch.Text = "Search";
            this.btnSearch.UseVisualStyleBackColor = false;
            this.btnSearch.Click += new System.EventHandler(this.btnNameSearch);
            // 
            // employeeDGV
            // 
            this.employeeDGV.AllowUserToAddRows = false;
            this.employeeDGV.BackgroundColor = System.Drawing.Color.Red;
            this.employeeDGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.employeeDGV.Cursor = System.Windows.Forms.Cursors.Cross;
            this.employeeDGV.Location = new System.Drawing.Point(86, 286);
            this.employeeDGV.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.employeeDGV.Name = "employeeDGV";
            this.employeeDGV.RowHeadersWidth = 62;
            this.employeeDGV.RowTemplate.Height = 33;
            this.employeeDGV.Size = new System.Drawing.Size(904, 199);
            this.employeeDGV.TabIndex = 4;
            // 
            // lblEmployeeTbl
            // 
            this.lblEmployeeTbl.AutoSize = true;
            this.lblEmployeeTbl.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblEmployeeTbl.ForeColor = System.Drawing.Color.White;
            this.lblEmployeeTbl.Location = new System.Drawing.Point(322, 255);
            this.lblEmployeeTbl.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblEmployeeTbl.Name = "lblEmployeeTbl";
            this.lblEmployeeTbl.Size = new System.Drawing.Size(149, 25);
            this.lblEmployeeTbl.TabIndex = 5;
            this.lblEmployeeTbl.Text = "Employee Table";
            // 
            // lblNoOfEmployee
            // 
            this.lblNoOfEmployee.AutoSize = true;
            this.lblNoOfEmployee.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblNoOfEmployee.ForeColor = System.Drawing.Color.White;
            this.lblNoOfEmployee.Location = new System.Drawing.Point(566, 255);
            this.lblNoOfEmployee.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblNoOfEmployee.Name = "lblNoOfEmployee";
            this.lblNoOfEmployee.Size = new System.Drawing.Size(167, 25);
            this.lblNoOfEmployee.TabIndex = 6;
            this.lblNoOfEmployee.Text = "No of Employees:";
            // 
            // ProjectSearchForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1121, 500);
            this.Controls.Add(this.lblNoOfEmployee);
            this.Controls.Add(this.lblEmployeeTbl);
            this.Controls.Add(this.employeeDGV);
            this.Controls.Add(this.btnSearch);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dgvMain);
            this.Controls.Add(this.tbxName);
            this.Cursor = System.Windows.Forms.Cursors.Cross;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "ProjectSearchForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ProjectSearchForm";
            ((System.ComponentModel.ISupportInitialize)(this.dgvMain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.employeeDGV)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbxName;
        private System.Windows.Forms.DataGridView dgvMain;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnSearch;
        private System.Windows.Forms.DataGridView employeeDGV;
        private System.Windows.Forms.Label lblEmployeeTbl;
        private System.Windows.Forms.Label lblNoOfEmployee;
    }
}