﻿using ProjectManagment.dbAccess;
using ProjectManagment.objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ProjectManagment.gui
{
    public partial class ProjectSearchForm : Form
    {
        Database db;
        public ProjectSearchForm()
        {
            InitializeComponent();
            db = new Database();
            if (db.Connect())
            {

            }
            else
            {
                MessageBox.Show("Not connected to database :(");
            }
        }

        private void btnNameSearch(object sender, EventArgs e)
        {
            ProjectDBAccess projectDBAccess = new ProjectDBAccess(db);
            DataTable dt = new DataTable();

            if (tbxName.Text == null)
            {
                MessageBox.Show("You have not selected a query");
            }
            else
            {
                try
                {
                    projectDBAccess.GetAllProjectsWithName(tbxName.Text);
                    dt = projectDBAccess.GetProjectDataTable();
                    dgvMain.DataSource = dt;

                }
                catch
                {
                    MessageBox.Show("Invalid Project name, Please try again");
                }
            }
        }

        private void DGVcellClick(object sender, DataGridViewCellEventArgs e)
        {
            ProjectDBAccess projectDBAccess = new ProjectDBAccess(db);
            DataTable dt = new DataTable();
            int projectID = int.Parse(dgvMain.CurrentRow.Cells[0].Value.ToString());           
            projectDBAccess.GetSelectedEmployeeDetails(Convert.ToString(projectID));
            dt = projectDBAccess.GetProjectDataTable();
            employeeDGV.DataSource = dt;
            int noOfEmploy = employeeDGV.RowCount;
            lblNoOfEmployee.Text = (noOfEmploy.ToString());

        }
    }
}
