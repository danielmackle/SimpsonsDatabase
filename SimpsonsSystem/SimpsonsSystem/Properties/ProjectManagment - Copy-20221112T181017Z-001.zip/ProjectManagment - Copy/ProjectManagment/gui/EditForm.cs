﻿using ProjectManagment.dbAccess;
using ProjectManagment.objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ProjectManagment.gui
{
    public partial class EditForm : Form
    {
        Database db = MainApp.Db;
        public EditForm()
        {
            InitializeComponent();
            db = MainApp.Db;
            if (!db.Connect())
            {
                MessageBox.Show("database not connected");
            }

            populateCombo();
        }

        private void populateCombo()
        {
            ProjectDBAccess projectDB = new ProjectDBAccess(db);
            projectDB.GetAllProjects();
            foreach(Project p in projectDB.GetProjectObjectList())
            {
                cboboxSelect.Items.Add(p.ProjectCode + "-" + p.ProjectTitle);
            }
        }

        private void projectPicked(object sender, EventArgs e)
        {
            if(cboboxSelect.SelectedIndex == -1)
            {
                MessageBox.Show("You have not selected a project");
            }
            else
            {
                string[] selectedProject = new string[2];
                selectedProject = cboboxSelect.SelectedItem.ToString().Split('-');
                int projectCode = Convert.ToInt32(selectedProject[0]);
                ProjectDBAccess project = new ProjectDBAccess(db);
                project.GetProjectWithID(projectCode);

                //Populating form controls 
                Project p = project.GetProjectObject();
                tbxProjectID.Text = p.ProjectCode.ToString();
                tbxProjectTitle.Text = p.ProjectTitle.ToString();
                tbxProjectManager.Text = p.ProjectManager.ToString();
                tbxProjectBudget.Text = p.ProjectBudget.ToString();

                monCalStart.SetDate(p.ProjectStartDate);
                monthCalEnd.SetDate(p.ProjectEndDate);

                cbxCompleted.Checked = p.ProjectCompleted;
                
            }
        }

        private void editClick(object sender, EventArgs e)
        {
            bool valid = true;
            ProjectDBAccess p = new ProjectDBAccess(db);
            Project project = new Project();
            project.ProjectCode = Convert.ToInt32(tbxProjectID.Text);
            project.ProjectTitle = tbxProjectTitle.Text;
            try
            {
                project.ProjectManager = tbxProjectManager.Text;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                valid = false;
            }

            project.ProjectBudget = Convert.ToDecimal(tbxProjectBudget.Text);

            try
            {
                project.ProjectStartDate = monCalStart.SelectionStart;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                valid = false;
            }

            try
            {
                project.ProjectEndDate = monthCalEnd.SelectionStart;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
                valid = false;
            }

            project.ProjectCompleted = cbxCompleted.Checked;

            if (valid)
            {
                p.UpdateProject(project);
                MessageBox.Show("Project Updated");
                Clear();
            }
            else
            {
                MessageBox.Show("invalid validation");
            }
            

        }

        private void Clear()
        {
            tbxProjectBudget.Text = "";
            tbxProjectID.Text = "";
            tbxProjectManager.Text = "";
            tbxProjectTitle.Text = "";
            monCalStart.SelectionStart = DateTime.Now;
            monthCalEnd.SelectionStart = DateTime.Now;
            cbxCompleted.Checked = false;
        }
    }

}
