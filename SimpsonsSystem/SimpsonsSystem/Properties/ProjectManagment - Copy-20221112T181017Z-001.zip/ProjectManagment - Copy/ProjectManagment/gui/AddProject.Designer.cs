﻿
namespace ProjectManagment.gui
{
    partial class AddProject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblProjectTitle = new System.Windows.Forms.Label();
            this.lblProjectManager = new System.Windows.Forms.Label();
            this.lblProjectBudget = new System.Windows.Forms.Label();
            this.lblStartdate = new System.Windows.Forms.Label();
            this.lblEndDate = new System.Windows.Forms.Label();
            this.tbxProjectTitle = new System.Windows.Forms.TextBox();
            this.tbxProjectManager = new System.Windows.Forms.TextBox();
            this.tbxProjectBudget = new System.Windows.Forms.TextBox();
            this.monCalStart = new System.Windows.Forms.MonthCalendar();
            this.monthCalEnd = new System.Windows.Forms.MonthCalendar();
            this.cbxCompleted = new System.Windows.Forms.CheckBox();
            this.btnAddProject = new System.Windows.Forms.Button();
            this.btnCancelEdit = new System.Windows.Forms.Button();
            this.lboxAvailableEmp = new System.Windows.Forms.ListBox();
            this.lboxSelectEmp = new System.Windows.Forms.ListBox();
            this.btnSelect = new System.Windows.Forms.Button();
            this.btnDeselect = new System.Windows.Forms.Button();
            this.lblAvailable = new System.Windows.Forms.Label();
            this.lblSelect = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblProjectTitle
            // 
            this.lblProjectTitle.ForeColor = System.Drawing.Color.Red;
            this.lblProjectTitle.Location = new System.Drawing.Point(10, 8);
            this.lblProjectTitle.Name = "lblProjectTitle";
            this.lblProjectTitle.Size = new System.Drawing.Size(191, 43);
            this.lblProjectTitle.TabIndex = 2;
            this.lblProjectTitle.Text = "Project Title";
            // 
            // lblProjectManager
            // 
            this.lblProjectManager.ForeColor = System.Drawing.Color.Red;
            this.lblProjectManager.Location = new System.Drawing.Point(10, 69);
            this.lblProjectManager.Name = "lblProjectManager";
            this.lblProjectManager.Size = new System.Drawing.Size(247, 43);
            this.lblProjectManager.TabIndex = 3;
            this.lblProjectManager.Text = "Project Manager";
            // 
            // lblProjectBudget
            // 
            this.lblProjectBudget.ForeColor = System.Drawing.Color.Red;
            this.lblProjectBudget.Location = new System.Drawing.Point(10, 131);
            this.lblProjectBudget.Name = "lblProjectBudget";
            this.lblProjectBudget.Size = new System.Drawing.Size(228, 43);
            this.lblProjectBudget.TabIndex = 4;
            this.lblProjectBudget.Text = "Project Budget";
            // 
            // lblStartdate
            // 
            this.lblStartdate.ForeColor = System.Drawing.Color.Red;
            this.lblStartdate.Location = new System.Drawing.Point(902, 82);
            this.lblStartdate.Name = "lblStartdate";
            this.lblStartdate.Size = new System.Drawing.Size(268, 43);
            this.lblStartdate.TabIndex = 5;
            this.lblStartdate.Text = "Project Start Date";
            // 
            // lblEndDate
            // 
            this.lblEndDate.ForeColor = System.Drawing.Color.Red;
            this.lblEndDate.Location = new System.Drawing.Point(1147, 150);
            this.lblEndDate.Name = "lblEndDate";
            this.lblEndDate.Size = new System.Drawing.Size(247, 43);
            this.lblEndDate.TabIndex = 6;
            this.lblEndDate.Text = "Project End Date";
            // 
            // tbxProjectTitle
            // 
            this.tbxProjectTitle.BackColor = System.Drawing.Color.Gray;
            this.tbxProjectTitle.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.tbxProjectTitle.Location = new System.Drawing.Point(288, 18);
            this.tbxProjectTitle.Name = "tbxProjectTitle";
            this.tbxProjectTitle.Size = new System.Drawing.Size(277, 32);
            this.tbxProjectTitle.TabIndex = 9;
            // 
            // tbxProjectManager
            // 
            this.tbxProjectManager.BackColor = System.Drawing.Color.Gray;
            this.tbxProjectManager.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.tbxProjectManager.Location = new System.Drawing.Point(288, 79);
            this.tbxProjectManager.Name = "tbxProjectManager";
            this.tbxProjectManager.Size = new System.Drawing.Size(277, 32);
            this.tbxProjectManager.TabIndex = 10;
            // 
            // tbxProjectBudget
            // 
            this.tbxProjectBudget.BackColor = System.Drawing.Color.Gray;
            this.tbxProjectBudget.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.tbxProjectBudget.Location = new System.Drawing.Point(288, 141);
            this.tbxProjectBudget.Name = "tbxProjectBudget";
            this.tbxProjectBudget.Size = new System.Drawing.Size(277, 32);
            this.tbxProjectBudget.TabIndex = 11;
            // 
            // monCalStart
            // 
            this.monCalStart.Location = new System.Drawing.Point(663, 79);
            this.monCalStart.Name = "monCalStart";
            this.monCalStart.TabIndex = 12;
            // 
            // monthCalEnd
            // 
            this.monthCalEnd.Location = new System.Drawing.Point(908, 150);
            this.monthCalEnd.Name = "monthCalEnd";
            this.monthCalEnd.TabIndex = 13;
            // 
            // cbxCompleted
            // 
            this.cbxCompleted.AutoSize = true;
            this.cbxCompleted.ForeColor = System.Drawing.Color.White;
            this.cbxCompleted.Location = new System.Drawing.Point(854, 387);
            this.cbxCompleted.Name = "cbxCompleted";
            this.cbxCompleted.Size = new System.Drawing.Size(209, 29);
            this.cbxCompleted.TabIndex = 14;
            this.cbxCompleted.Text = "Project Completed ?";
            this.cbxCompleted.UseVisualStyleBackColor = true;
            // 
            // btnAddProject
            // 
            this.btnAddProject.BackColor = System.Drawing.Color.Purple;
            this.btnAddProject.ForeColor = System.Drawing.Color.White;
            this.btnAddProject.Location = new System.Drawing.Point(854, 515);
            this.btnAddProject.Name = "btnAddProject";
            this.btnAddProject.Size = new System.Drawing.Size(224, 52);
            this.btnAddProject.TabIndex = 15;
            this.btnAddProject.Text = "Add Project";
            this.btnAddProject.UseVisualStyleBackColor = false;
            this.btnAddProject.Click += new System.EventHandler(this.addClick);
            // 
            // btnCancelEdit
            // 
            this.btnCancelEdit.BackColor = System.Drawing.Color.Purple;
            this.btnCancelEdit.ForeColor = System.Drawing.Color.White;
            this.btnCancelEdit.Location = new System.Drawing.Point(854, 453);
            this.btnCancelEdit.Name = "btnCancelEdit";
            this.btnCancelEdit.Size = new System.Drawing.Size(224, 52);
            this.btnCancelEdit.TabIndex = 16;
            this.btnCancelEdit.Text = "Cancel Edit";
            this.btnCancelEdit.UseVisualStyleBackColor = false;
            // 
            // lboxAvailableEmp
            // 
            this.lboxAvailableEmp.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.lboxAvailableEmp.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lboxAvailableEmp.ForeColor = System.Drawing.Color.White;
            this.lboxAvailableEmp.FormattingEnabled = true;
            this.lboxAvailableEmp.ItemHeight = 21;
            this.lboxAvailableEmp.Location = new System.Drawing.Point(7, 308);
            this.lboxAvailableEmp.Name = "lboxAvailableEmp";
            this.lboxAvailableEmp.Size = new System.Drawing.Size(261, 214);
            this.lboxAvailableEmp.TabIndex = 19;
            // 
            // lboxSelectEmp
            // 
            this.lboxSelectEmp.BackColor = System.Drawing.Color.MediumBlue;
            this.lboxSelectEmp.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lboxSelectEmp.ForeColor = System.Drawing.Color.White;
            this.lboxSelectEmp.FormattingEnabled = true;
            this.lboxSelectEmp.ItemHeight = 21;
            this.lboxSelectEmp.Location = new System.Drawing.Point(393, 308);
            this.lboxSelectEmp.Name = "lboxSelectEmp";
            this.lboxSelectEmp.Size = new System.Drawing.Size(257, 214);
            this.lboxSelectEmp.TabIndex = 20;
            // 
            // btnSelect
            // 
            this.btnSelect.BackColor = System.Drawing.Color.Purple;
            this.btnSelect.Font = new System.Drawing.Font("Segoe UI Black", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnSelect.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.btnSelect.Location = new System.Drawing.Point(298, 345);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(67, 51);
            this.btnSelect.TabIndex = 21;
            this.btnSelect.Text = ">";
            this.btnSelect.UseVisualStyleBackColor = false;
            this.btnSelect.Click += new System.EventHandler(this.SelectClick);
            // 
            // btnDeselect
            // 
            this.btnDeselect.BackColor = System.Drawing.Color.Purple;
            this.btnDeselect.Font = new System.Drawing.Font("Segoe UI Black", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.btnDeselect.ForeColor = System.Drawing.Color.BlanchedAlmond;
            this.btnDeselect.Location = new System.Drawing.Point(298, 453);
            this.btnDeselect.Name = "btnDeselect";
            this.btnDeselect.Size = new System.Drawing.Size(67, 51);
            this.btnDeselect.TabIndex = 22;
            this.btnDeselect.Text = "<";
            this.btnDeselect.UseVisualStyleBackColor = false;
            this.btnDeselect.Click += new System.EventHandler(this.deselectClick);
            // 
            // lblAvailable
            // 
            this.lblAvailable.ForeColor = System.Drawing.Color.Red;
            this.lblAvailable.Location = new System.Drawing.Point(1, 213);
            this.lblAvailable.Name = "lblAvailable";
            this.lblAvailable.Size = new System.Drawing.Size(261, 79);
            this.lblAvailable.TabIndex = 23;
            this.lblAvailable.Text = "Available Employees";
            // 
            // lblSelect
            // 
            this.lblSelect.ForeColor = System.Drawing.Color.Red;
            this.lblSelect.Location = new System.Drawing.Point(382, 213);
            this.lblSelect.Name = "lblSelect";
            this.lblSelect.Size = new System.Drawing.Size(257, 79);
            this.lblSelect.TabIndex = 24;
            this.lblSelect.Text = "Selected Employees";
            // 
            // AddProject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Aqua;
            this.ClientSize = new System.Drawing.Size(1320, 579);
            this.Controls.Add(this.lblSelect);
            this.Controls.Add(this.lblAvailable);
            this.Controls.Add(this.btnDeselect);
            this.Controls.Add(this.btnSelect);
            this.Controls.Add(this.lboxSelectEmp);
            this.Controls.Add(this.lboxAvailableEmp);
            this.Controls.Add(this.btnCancelEdit);
            this.Controls.Add(this.btnAddProject);
            this.Controls.Add(this.cbxCompleted);
            this.Controls.Add(this.monthCalEnd);
            this.Controls.Add(this.monCalStart);
            this.Controls.Add(this.tbxProjectBudget);
            this.Controls.Add(this.tbxProjectManager);
            this.Controls.Add(this.tbxProjectTitle);
            this.Controls.Add(this.lblEndDate);
            this.Controls.Add(this.lblStartdate);
            this.Controls.Add(this.lblProjectBudget);
            this.Controls.Add(this.lblProjectManager);
            this.Controls.Add(this.lblProjectTitle);
            this.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.ForeColor = System.Drawing.Color.Red;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "AddProject";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddForm";
            this.Load += new System.EventHandler(this.AddProject_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblProjectTitle;
        private System.Windows.Forms.Label lblProjectManager;
        private System.Windows.Forms.Label lblProjectBudget;
        private System.Windows.Forms.Label lblStartdate;
        private System.Windows.Forms.Label lblEndDate;
        private System.Windows.Forms.TextBox tbxProjectTitle;
        private System.Windows.Forms.TextBox tbxProjectManager;
        private System.Windows.Forms.TextBox tbxProjectBudget;
        private System.Windows.Forms.MonthCalendar monCalStart;
        private System.Windows.Forms.MonthCalendar monthCalEnd;
        private System.Windows.Forms.CheckBox cbxCompleted;
        private System.Windows.Forms.Button btnAddProject;
        private System.Windows.Forms.Button btnCancelEdit;
        private System.Windows.Forms.ListBox lboxAvailableEmp;
        private System.Windows.Forms.ListBox lboxSelectEmp;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.Button btnDeselect;
        private System.Windows.Forms.Label lblAvailable;
        private System.Windows.Forms.Label lblSelect;
    }
}