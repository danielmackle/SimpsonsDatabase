﻿
namespace ProjectManagment
{
    partial class SearchForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.queryCBox = new System.Windows.Forms.ComboBox();
            this.resultsDataGrid = new System.Windows.Forms.DataGridView();
            this.SelectQueToPreform = new System.Windows.Forms.Label();
            this.lblResultsSetSize = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.tbxProjectId = new System.Windows.Forms.TextBox();
            this.btnSearchForText = new System.Windows.Forms.Button();
            this.lblSelectProjectId = new System.Windows.Forms.Label();
            this.lblprojectResults = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.resultsDataGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // queryCBox
            // 
            this.queryCBox.BackColor = System.Drawing.Color.White;
            this.queryCBox.ForeColor = System.Drawing.Color.White;
            this.queryCBox.FormattingEnabled = true;
            this.queryCBox.Location = new System.Drawing.Point(329, 31);
            this.queryCBox.Name = "queryCBox";
            this.queryCBox.Size = new System.Drawing.Size(837, 33);
            this.queryCBox.TabIndex = 0;
            // 
            // resultsDataGrid
            // 
            this.resultsDataGrid.BackgroundColor = System.Drawing.Color.Honeydew;
            this.resultsDataGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.resultsDataGrid.Location = new System.Drawing.Point(12, 140);
            this.resultsDataGrid.Name = "resultsDataGrid";
            this.resultsDataGrid.RowHeadersWidth = 62;
            this.resultsDataGrid.RowTemplate.Height = 33;
            this.resultsDataGrid.Size = new System.Drawing.Size(1153, 184);
            this.resultsDataGrid.TabIndex = 2;
            // 
            // SelectQueToPreform
            // 
            this.SelectQueToPreform.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.SelectQueToPreform.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SelectQueToPreform.ForeColor = System.Drawing.Color.White;
            this.SelectQueToPreform.Location = new System.Drawing.Point(7, 31);
            this.SelectQueToPreform.Name = "SelectQueToPreform";
            this.SelectQueToPreform.Size = new System.Drawing.Size(316, 46);
            this.SelectQueToPreform.TabIndex = 3;
            this.SelectQueToPreform.Text = "Select Query to Preform";
            // 
            // lblResultsSetSize
            // 
            this.lblResultsSetSize.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblResultsSetSize.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblResultsSetSize.ForeColor = System.Drawing.Color.White;
            this.lblResultsSetSize.Location = new System.Drawing.Point(993, 559);
            this.lblResultsSetSize.Name = "lblResultsSetSize";
            this.lblResultsSetSize.Size = new System.Drawing.Size(173, 47);
            this.lblResultsSetSize.TabIndex = 4;
            this.lblResultsSetSize.Text = " 0  ";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.SpringGreen;
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(31, 83);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(167, 51);
            this.button1.TabIndex = 5;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.btnSearchClick);
            // 
            // tbxProjectId
            // 
            this.tbxProjectId.BackColor = System.Drawing.Color.DarkSlateGray;
            this.tbxProjectId.ForeColor = System.Drawing.Color.White;
            this.tbxProjectId.Location = new System.Drawing.Point(12, 390);
            this.tbxProjectId.Name = "tbxProjectId";
            this.tbxProjectId.Size = new System.Drawing.Size(311, 32);
            this.tbxProjectId.TabIndex = 6;
            // 
            // btnSearchForText
            // 
            this.btnSearchForText.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnSearchForText.ForeColor = System.Drawing.Color.White;
            this.btnSearchForText.Location = new System.Drawing.Point(382, 367);
            this.btnSearchForText.Name = "btnSearchForText";
            this.btnSearchForText.Size = new System.Drawing.Size(167, 55);
            this.btnSearchForText.TabIndex = 7;
            this.btnSearchForText.Text = "Search";
            this.btnSearchForText.UseVisualStyleBackColor = false;
            this.btnSearchForText.Click += new System.EventHandler(this.SearchTextClick);
            // 
            // lblSelectProjectId
            // 
            this.lblSelectProjectId.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblSelectProjectId.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblSelectProjectId.ForeColor = System.Drawing.Color.White;
            this.lblSelectProjectId.Location = new System.Drawing.Point(12, 330);
            this.lblSelectProjectId.Name = "lblSelectProjectId";
            this.lblSelectProjectId.Size = new System.Drawing.Size(243, 46);
            this.lblSelectProjectId.TabIndex = 8;
            this.lblSelectProjectId.Text = "Enter a ProjectID";
            // 
            // lblprojectResults
            // 
            this.lblprojectResults.BackColor = System.Drawing.Color.Honeydew;
            this.lblprojectResults.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lblprojectResults.ForeColor = System.Drawing.Color.White;
            this.lblprojectResults.Location = new System.Drawing.Point(585, 330);
            this.lblprojectResults.Name = "lblprojectResults";
            this.lblprojectResults.Size = new System.Drawing.Size(580, 217);
            this.lblprojectResults.TabIndex = 9;
            // 
            // SearchForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Tan;
            this.ClientSize = new System.Drawing.Size(1199, 773);
            this.Controls.Add(this.lblprojectResults);
            this.Controls.Add(this.lblSelectProjectId);
            this.Controls.Add(this.btnSearchForText);
            this.Controls.Add(this.tbxProjectId);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblResultsSetSize);
            this.Controls.Add(this.SelectQueToPreform);
            this.Controls.Add(this.resultsDataGrid);
            this.Controls.Add(this.queryCBox);
            this.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "SearchForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "SearchForm";
            ((System.ComponentModel.ISupportInitialize)(this.resultsDataGrid)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox queryCBox;
        private System.Windows.Forms.DataGridView resultsDataGrid;
        private System.Windows.Forms.Label SelectQueToPreform;
        private System.Windows.Forms.Label lblResultsSetSize;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tbxProjectId;
        private System.Windows.Forms.Button btnSearchForText;
        private System.Windows.Forms.Label lblSelectProjectId;
        private System.Windows.Forms.Label lblprojectResults;
    }
}

