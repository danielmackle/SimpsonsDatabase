﻿using ProjectManagment.dbAccess;
using ProjectManagment.objects;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ProjectManagment.gui
{
    public partial class AddProject : Form
    {
        Database db = MainApp.Db;
        public AddProject()
        {
            InitializeComponent();
            db = MainApp.Db;
            if (!db.Connect())
            {
                MessageBox.Show("database not connected");
            }
            PopulateAvailableEmployees();
        }

        private void Clear()
        {
            tbxProjectBudget.Text = "";
            tbxProjectManager.Text = "";
            tbxProjectTitle.Text = "";
            monCalStart.SelectionStart = DateTime.Now;
            monthCalEnd.SelectionStart = DateTime.Now;
            cbxCompleted.Checked = false;
        }

        private void addClick(object sender, EventArgs e)
        {
            ProjectDBAccess p = new ProjectDBAccess(db);
            Project project = new Project();
            bool valid = true;
            project.ProjectTitle = tbxProjectTitle.Text;

            try
            {
                project.ProjectManager = tbxProjectManager.Text;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message); valid = false;
            }
            try
            {
                project.ProjectStartDate = monCalStart.SelectionStart;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message); valid = false;
            }
            try
            {
                project.ProjectEndDate = monthCalEnd.SelectionStart;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message); valid = false;
            }

            project.ProjectBudget = Convert.ToDecimal(tbxProjectBudget.Text);

            project.ProjectCompleted = cbxCompleted.Checked;

            if (valid)
            {
                p.AddNewProject(project);
                foreach (var employee in lboxSelectEmp.Items)
                {
                    ProjectDBAccess pDBAcess = new ProjectDBAccess();
                    EmployeeDBAccess eDBAccess = new EmployeeDBAccess();
                    eDBAccess.GetAllEmployeeByName(employee.ToString());
                    Employee emp = eDBAccess.GetEmployeeObject();
                    Project proj = pDBAcess.GetProjectObject();
                    int employeeID = emp.EmployeeNo;
                    int projectID = pDBAcess.GetLastProjectID();
                }
                MessageBox.Show("Project Added");
                Clear();
            }
            else
            {
                MessageBox.Show("project not added lol");
            }
        }

        private void PopulateAvailableEmployees()
        {
            EmployeeDBAccess e = new EmployeeDBAccess(db);
            e.getAllEmployees();
            List<Employee> employeeList = e.GetEmployeeObjectList();
            foreach(Employee emp in employeeList)
            {
                lboxAvailableEmp.Items.Add(emp.EmployeeName);
            }
        }

        private void SelectClick(object sender, EventArgs e)
        {
            if(lboxAvailableEmp.SelectedIndex == -1)
            {
                MessageBox.Show("Please select an employee to be moved");
            }
            else
            {
                lboxSelectEmp.Items.Add(lboxAvailableEmp.SelectedItem.ToString());
                lboxAvailableEmp.Items.Remove(lboxAvailableEmp.SelectedItem.ToString());
            }
        }

        private void deselectClick(object sender, EventArgs e)
        {
            if(lboxSelectEmp.SelectedIndex == -1)
            {
                MessageBox.Show("Please select an employee to be moved");
            }
            else
            {
                lboxAvailableEmp.Items.Add(lboxSelectEmp.SelectedItem.ToString());
                lboxSelectEmp.Items.Remove(lboxSelectEmp.SelectedItem.ToString());
                lboxAvailableEmp.Sorted = true;
                lboxSelectEmp.Sorted = true;
            }
            
        }

        private void AddProject_Load(object sender, EventArgs e)
        {

        }
    }

}
