﻿using ProjectManagment.gui;
using ProjectManagment.objects;
using System;
using System.Collections.Generic;
using System.Text;

namespace ProjectManagment.dbAccess
{
    class EmployeeDBAccess
    {
        private Database db;

        public EmployeeDBAccess()
        {

        }

        public EmployeeDBAccess(Database _db)
        {
            db = _db;
        }

        public Employee GetEmployeeFromDataReader()
        {
            Employee emp = new Employee();
            //emp.EmployeeNo = db.Rdr.GetInt32(0);
            emp.EmployeeName = db.Rdr.GetString(0);
            //emp.DepartmentNo = db.Rdr.GetInt32(1);
            return emp;
        }

        public List<Employee> GetEmployeeObjectList()
        {
            List<Employee> results = new List<Employee>();
            while (db.Rdr.Read())
            {
                results.Add(GetEmployeeFromDataReader());
            }
            db.Rdr.Close();
            return results;
        }

        public void GetAllEmployeeByName(string input)
        {
            db = MainApp.Db;
            string sqlCmd = "SELECT * FROM Employee WHERE EmployeeName LIKE '%" + input + "%' ORDER BY EmployeeName";
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = sqlCmd;
            db.Rdr = db.Cmd.ExecuteReader();
        }

        public Employee GetEmployeeObject()
        {
            Employee employee = new Employee();
            while (db.Rdr.Read())
            {
                employee = GetEmployeeFromDataReader();
            }
            db.Rdr.Close();
            return employee;
        }


        public void getAllEmployees()
        {
            string sqlCmd = "SELECT EmployeeName FROM Employee ORDER BY EmployeeName";
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = sqlCmd;
            db.Rdr = db.Cmd.ExecuteReader();
        }
        
    }
}
