﻿using ProjectManagment.objects;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace ProjectManagment.dbAccess
{
    class ProjectDBAccess
    {
        private Database db;

        public ProjectDBAccess(Database _db)
        {
            db = _db;
        }

        public ProjectDBAccess()
        {

        }

        public Project GetProjectFromDataReader()
        {
            Project proj = new Project();
            proj.ProjectCode = db.Rdr.GetInt32(0);
            proj.ProjectTitle = db.Rdr.GetString(1);
            proj.ProjectManager = db.Rdr.GetString(2);
            proj.ProjectBudget = db.Rdr.GetDecimal(3);
            return proj;
        }

        public void AddNewProject(Project p)
        {
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "INSERT INTO Project VALUES ('" + p.ProjectTitle + "','" + p.ProjectManager + "'," + p.ProjectBudget + ",'" + p.ProjectStartDate.ToString("MM/dd/yyyy") + "','" + p.ProjectEndDate.ToString("MM/dd/yyyy") + "', '" + p.ProjectCompleted + "')";
            db.Cmd.ExecuteNonQuery();
        }

        public List<Project> GetProjectObjectList()
        {
            List<Project> results = new List<Project>();
            while (db.Rdr.Read())
            {
                results.Add(GetProjectFromDataReader());
            }
            db.Rdr.Close();
            return results;
        }

        public int GetLastProjectID()
        {
            int lastID;
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "SELECT MAX(Project.ProjectCode) FROM Project";
            lastID = Convert.ToInt32(db.Cmd.ExecuteNonQuery());
            return lastID;
        }

        public Project GetProjectObject()
        {
            Project project = new Project();
            while (db.Rdr.Read())
            {
                project = GetProjectFromDataReader();
            }
            db.Rdr.Close();
            return project;
        }

        public DataTable GetProjectDataTable()
        {
            DataTable dt = new DataTable();
            dt.Load(db.Rdr);
            return dt;
        }

        public void GetAllProjects()
        {
            string sqlCmd = "SELECT * FROM Project";
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = sqlCmd;
            db.Rdr = db.Cmd.ExecuteReader();
        }

        public void GetAllProjectsWithName(string input)
        {
            int count = 0;
            string sqlCmd = "SELECT * FROM Project WHERE ProjectTitle LIKE '%" + input + "%'";
            for(int i = 0; i < input.Length; i++)
            {
                foreach (char c in input)
                {                   
                    if (!Char.IsDigit(c))
                    {
                       count += 1;
                    }            
                }
                if (count == 0)
                {
                    sqlCmd += "OR ProjectCode = " + input.ToString();
                }
            }
            
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = sqlCmd;
            db.Rdr = db.Cmd.ExecuteReader();
        }

        public void GetProjectWithID(int id)
        {
            string sqlCmd = "SELECT * FROM Project WHERE ProjectCode = " + id.ToString();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = sqlCmd;
            db.Rdr = db.Cmd.ExecuteReader();
        }

        public void GetAllProjectsWithBudget(decimal rate, int op)
        {
            String sqlCmd = "SELECT * FROM Project WHERE ProjectBudget";
            switch (op)
            {
                case 1: sqlCmd += "="; break;
                case 2: sqlCmd += ">="; break;
                case 3: sqlCmd += "<="; break;
                case 4: sqlCmd += ">"; break;
                case 5: sqlCmd += "<"; break;
                case 6: sqlCmd += "<>"; break;
                default: sqlCmd += "="; break;
            }
            sqlCmd += rate.ToString();
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = sqlCmd;
            db.Rdr = db.Cmd.ExecuteReader();
        }

        public void GetAllProjectsWithManager(string manager)
        {
            String sqlCmd = "SELECT * FROM Project WHERE ProjectManager = '" + manager + "'";
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = sqlCmd;
            db.Rdr = db.Cmd.ExecuteReader();
        }

        public void GetSelectedEmployeeDetails(string value)
        {
            String sqlCmd = "SELECT Employee.EmployeeNo,EmployeeName,Department.DepartmentNo,DepartmentName " +
                "FROM ProjectSalary " +
                "INNER JOIN Employee " +
                "ON Employee.EmployeeNo = ProjectSalary.EmployeeNo " +
                "INNER JOIN Department " +
                "ON Department.DepartmentNo = Employee.DepartmentNo  " +
                "WHERE projectsalary.projectCode = '" + value + "'";
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = sqlCmd;
            db.Rdr = db.Cmd.ExecuteReader();

        }

        public Project getProjectFromReader()
        {
            Project proj = new Project();
            proj.ProjectCode = db.Rdr.GetInt32(0);
            proj.ProjectTitle = db.Rdr.GetString(1);
            proj.ProjectManager = db.Rdr.GetString(2);
            proj.ProjectBudget = db.Rdr.GetDecimal(3);
            proj.ProjectStartDate = db.Rdr.GetDateTime(4);
            proj.ProjectEndDate = db.Rdr.GetDateTime(5);
            proj.ProjectCompleted = db.Rdr.GetBoolean(6);
            return proj;
        }

        public void UpdateProject(Project p)
        {
            db.Cmd = db.Conn.CreateCommand();
            db.Cmd.CommandText = "UPDATE Project SET ProjectTitle = '" + p.ProjectTitle + "', ProjectManager = '" + p.ProjectManager + "', ProjectBudget = " + p.ProjectBudget + ", ProjectStartDate = '" + p.ProjectStartDate.ToString("MM/dd/yyyy") + "', ProjectEndDate = '" + p.ProjectEndDate.ToString("MM/dd/yyyy") + "', ProjectCompleted = '" + p.ProjectCompleted + "' WHERE ProjectCode = " + p.ProjectCode;
            db.Cmd.ExecuteNonQuery();
        }

    }
}
